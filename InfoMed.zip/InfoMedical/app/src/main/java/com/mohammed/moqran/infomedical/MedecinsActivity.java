package com.mohammed.moqran.infomedical;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;

public class MedecinsActivity extends AppCompatActivity {
    Button btnGenyco,btnPediatre,btnNeuro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);
        setContentView(R.layout.activity_medecins);

        btnGenyco=(Button)findViewById(R.id.gyneco);
        btnPediatre=(Button)findViewById(R.id.pediatre);
        btnNeuro=(Button)findViewById(R.id.neuro);


        btnGenyco.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MedecinsActivity.this,ListeGenyco.class);
                startActivity(intent);
            }
        });
        btnPediatre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MedecinsActivity.this,ListePediatre.class);
                startActivity(intent);
            }
        });
        btnNeuro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MedecinsActivity.this,ListeNeurologue.class);
                startActivity(intent);
            }
        });
    }
}
