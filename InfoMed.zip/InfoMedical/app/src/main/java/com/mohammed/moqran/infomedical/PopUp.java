package com.mohammed.moqran.infomedical;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.StrictMode;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class PopUp extends AppCompatActivity {
   // private static  final String url="jdbc:mysql://192.168.1.2:3306/pfe_bdd";
   private static  final String url="jdbc:mysql://192.168.43.251:3306/pfe_bdd";
    private static final String user="test";
    public static final String pass="test";

    TextView docteurInfo;
    String nom,adresse,tel ;
    Button btn;
    Button call;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pop_up);

        call=(Button) findViewById(R.id.call);
        docteurInfo=findViewById(R.id.docteurInfo);
        nom=getIntent().getExtras().getString("docteur");
        getInfo();
        docteurInfo.setText(nom+"\n\nTel: "+tel+"\n\nAdresse: "+adresse);
        //pour savoir les mecures par default de laa fenetre
        DisplayMetrics dm=new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        //recuperer la largeur et la hauteur
        int width=dm.widthPixels;
        int height=dm.heightPixels;
        //former notre fenetre
        getWindow().setLayout((int) (width*0.8),(int) (height*0.5));

    }
    void getInfo(){
        try {
            StrictMode.ThreadPolicy policy=new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn= DriverManager.getConnection(url,user,pass);

            Statement statement=conn.createStatement();
            ResultSet resultSet=statement.executeQuery("select tel,adresse from medecin where nom='"+nom.substring(4)+"';");
            ResultSetMetaData resultSetMetaData=resultSet.getMetaData();


            while(resultSet.next()){
                tel=resultSet.getString(1);
                adresse=resultSet.getString(2);

            }

        } catch (ClassNotFoundException e) {
            e.printStackTrace();

        } catch (SQLException e) {

            e.printStackTrace();
        }

    }
    public void appeler(View v)
    {
        try
        {
            //verifier la version du SDK

            if(Build.VERSION.SDK_INT > 22)
            {
                //verifier la permession CALL_PHONE

                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling

                    //demander la permession s'elle n'est pas donnée

                    ActivityCompat.requestPermissions(PopUp.this, new String[]{Manifest.permission.CALL_PHONE}, 101);

                    return;
                }

                //passer l'appel

                Intent callIntent = new Intent(Intent.ACTION_CALL);
                callIntent.setData(Uri.parse("tel:" + tel));
                startActivity(callIntent);

            }
            else {
                Intent callIntent = new Intent(Intent.ACTION_CALL);
                callIntent.setData(Uri.parse("tel:" + tel));
                startActivity(callIntent);
            }
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }

}
