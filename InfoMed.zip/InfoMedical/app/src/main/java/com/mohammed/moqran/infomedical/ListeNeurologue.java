package com.mohammed.moqran.infomedical;

import android.content.Intent;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

public class ListeNeurologue extends AppCompatActivity {
    //private static  final String url="jdbc:mysql://192.168.1.2:3306/pfe_bdd";
    private static  final String url="jdbc:mysql://192.168.43.251:3306/pfe_bdd";
    private static final String user="test";
    public static final String pass="test";

    private Vector<String> liste=new Vector<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_liste_neurologue);
        ListView listView=(ListView)findViewById(R.id.listeNeurologue);
        testDB(liste);
        ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,liste);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(ListeNeurologue.this, liste.elementAt(position),Toast.LENGTH_SHORT).show();
                Intent intent=new Intent(ListeNeurologue.this,PopUp.class);
                intent.putExtra("docteur",liste.elementAt(position));
                startActivity(intent);
            }
        });
    }
    public void testDB(Vector<String> liste){



        try {
            StrictMode.ThreadPolicy policy=new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn= DriverManager.getConnection(url,user,pass);

            Statement statement=conn.createStatement();
            ResultSet resultSet=statement.executeQuery("select nom from medecin where specialite='neurologue' order by nom;");
            ResultSetMetaData resultSetMetaData=resultSet.getMetaData();


            while(resultSet.next()){
                liste.addElement("Dr. "+resultSet.getString(1));


            }

        } catch (ClassNotFoundException e) {
            e.printStackTrace();

        } catch (SQLException e) {

            e.printStackTrace();
        }
    }
}
